/**
 * ex04_script.js
 
 	js 클래스 선언
 	js 함수 선엄
 */
 
 function nameAlert(name){
 	alert(`${name} 님 환영합니다.`);
 }